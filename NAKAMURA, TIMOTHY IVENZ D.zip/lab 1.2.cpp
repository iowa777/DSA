#include <iostream>
using namespace std;

int main()
{
	int num, bin;
	cout<< "Enter a positive integer: \n";
	enter:
	cin >> num;
	if(num<=0||cin.get()!='\n')
	{
		cout<<"Invalid input, try again. \n";
		cin.clear();
		cin.sync();
		goto enter;
	}
	cout<< "The binary equivalent of " << num << " is: \n";
	while (num > 0)
	{
		bin = num%2;
		cout << bin;
		num/=2;
	}
	return 0;
}
