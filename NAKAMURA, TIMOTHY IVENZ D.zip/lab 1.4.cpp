#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	cout<<"Enter a word: ";
	char word[100];
	cin>>word;
	
	int i = 0;
	int letters = strlen(word)-1;
	
	for (i=0;i<letters;i++)
	{
		if(word[i] !=word[letters])
		{
			cout<<word<<" is not Palindrome";
			exit(1);
		}
		letters--;
	}
	
	cout<<word<<" is Palindrome";
} 
