#include <iostream>

using namespace std;

	int max (int num1, int num2)
	{
	int ans;
	
		if(num1>num2)
		{
			ans = num1;
		}
		else
		{
			ans = num2;
		}
	}
	
	int main()
	{
		int fnum,snum;
		cout<<"First number: \n";
		cin>>fnum;
		cout<<"Second number: \n";
		cin>>snum;
		cout<<"The Greatest number is: \n\n"<< max(fnum,snum)<<endl;		
	}
