#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int a, fact=1, number;
		cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
		cout<<"!!!!!""Factorial Activity!!!!!\n";
		cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n";
		cout<<"Enter any number: ";
		entnum:
			
		cin>>number;
			if (number <=0 || cin.get() != '\n')
				{
					cout<<"Invalid Input has been selected.\nPlease choose a valid input"<<endl;
					cin.clear();
					cin.sync();
					goto entnum;
				}
				
			else 
			{
				for (a=1; a<=number; a++)
					{
						fact = fact * a;
					}
					cout<<" \nThe Factorial of " <<number<<" is:\n\n" <<fact<<endl;
			}
}
