#include <iostream>
#include <conio.h>

using namespace std; 

int  main ()

{
   int x, t, array[10];

   		cout << "		_________________________________________\n";
        cout << "		|-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-|\n";
        cout << "		|-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-|\n";
        cout << "		|-+-+-+- Enter 10 integer number: -+-+-+|\n";
        cout << "		|-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-|\n";
        cout << "		-----------------------------------------\n\n";
		for (x=0; x<10; x++)
		{
			while(!(cin>>array[x]))
			{
				cout<<"Invalid input, try again"<<endl;
				cin.clear();
				cin.sync();
			}  
        }
        for (x=0; x<10; x++)
		{      
                for (int y=0; y<9; y++)
                {
                        if(array[y]>array[y+1])
                        {
                t=array[y];
                array[y]=array[y+1];
                array[y+1]=t;
                        }
                }
        }
        cout << "The integers in ascending order are : ";
        for (x=0;x<10;x++)
        {  
		   cout <<"\n";
           cout <<array[x];
           cout << "\n";
        }
     system ("pause");
        return 0;  
        } 
