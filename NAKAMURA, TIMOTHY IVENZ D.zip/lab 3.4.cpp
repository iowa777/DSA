#include <iostream>
#include <string>

using namespace std;

void reverseStr(string& str){
  
    int n = str.length();
    for (int i = 0; i < n / 2; i++) 
        swap(str[i], str[n - i - 1]); 
}
int main(){
	string str, rev;

	cout << "Enter a word: ";
	getline(cin, str);

	rev = str;
	reverseStr(rev);

	cout << str << " is ";
	str == rev ?: (cout << "not ");
	cout << "a palindrome" << endl;

	system("pause>0");
	return 0;
}
